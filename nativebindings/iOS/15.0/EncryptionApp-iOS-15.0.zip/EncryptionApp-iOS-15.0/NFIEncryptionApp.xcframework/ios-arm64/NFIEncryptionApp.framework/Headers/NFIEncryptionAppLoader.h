#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIEncryptionAppModules(JSContext* context);
JSValue* extractNFIEncryptionAppStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIEncryptionAppStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
