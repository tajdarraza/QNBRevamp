#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_EncryptionApp_EncryptionApp_Swift_symbols(JSContext*);
@protocol EncryptionViewControllerInstanceExports<JSExport>
-(void) viewDidLoad;
-(NSString *) encryptDataWithRSAPublicKeyWithData: (NSString *) data publicKey: (NSString *) publicKey ;
-(NSString *) encryptDataWithRSAPublicKeyOAEPWithData: (NSString *) data publicKey: (NSString *) publicKey ;
-(NSString *) decryptDataWithRSAPrivateKeyWithData: (NSString *) data privateKey: (NSString *) privateKey ;
-(NSString *) encryptionWithRSAPBKDFWithInputValue: (NSString *) inputValue publicKey: (NSString *) publicKey salt: (NSString *) salt keyLengthCount: (NSString *) keyLengthCount rounds: (NSString *) rounds ;
JSExportAs(initWithNibNameBundle,
-(id) jsinitWithNibName: (NSString *) nibNameOrNil bundle: (NSBundle *) nibBundleOrNil );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol EncryptionViewControllerClassExports<JSExport>
@end
@protocol RSAUtilsInstanceExports<JSExport>
-(id) jsinit;
@end
@protocol RSAUtilsClassExports<JSExport>
@end
#pragma clang diagnostic pop