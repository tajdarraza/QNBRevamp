#import "allincludes.h"
#import <JavaScriptCore/JavaScriptCore.h>
void loadNFIEncryptionAppModules(JSContext* context)
{
	load_EncryptionApp_EncryptionApp_Swift_symbols(context);
	load_EncryptionApp_EncryptionKonyFFIWrapper_symbols(context);
	load_EncryptionApp_EncryptionApp_symbols(context);
}

JSValue* extractNFIEncryptionAppStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context)
{
    
    return nil;
}

BOOL setNFIEncryptionAppStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation)
{
    
    return NO;
}

