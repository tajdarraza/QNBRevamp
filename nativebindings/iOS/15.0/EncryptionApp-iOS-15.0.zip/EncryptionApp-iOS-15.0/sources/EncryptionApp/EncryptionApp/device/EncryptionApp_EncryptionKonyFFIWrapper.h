#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_EncryptionApp_EncryptionKonyFFIWrapper_symbols(JSContext*);
@protocol EncryptionKonyFFIWrapperInstanceExports<JSExport>
@end
@protocol EncryptionKonyFFIWrapperClassExports<JSExport>
+(NSString *) encrytDataWithRSAPublicKey: (NSString *) inputData : (NSString *) publicKey ;
+(NSString *) encrytDataWithRSAPublicKeyOAEP: (NSString *) inputData : (NSString *) publicKey ;
+(NSString *) decryptDataWithRSAPrivateKey: (NSString *) inputData : (NSString *) privateKey ;
+(NSString *) encrytDataWithRSAPBKDF: (NSString *) inputValue : (NSString *) publicKey : (NSString *) salt : (NSString *) keyLength : (NSString *) iterations ;
+(NSString *) encrytRSAData;
@end
#pragma clang diagnostic pop